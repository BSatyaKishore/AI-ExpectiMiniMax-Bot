#!/bin/bash
python -u myAI.py
