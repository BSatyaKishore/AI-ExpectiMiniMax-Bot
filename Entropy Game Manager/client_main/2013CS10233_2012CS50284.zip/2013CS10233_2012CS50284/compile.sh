chmod +x 777 myAI.py
